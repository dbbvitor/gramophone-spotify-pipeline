# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src']

package_data = \
{'': ['*']}

install_requires = \
['findspark>=2.0.1,<3.0.0',
 'luigi[toml]>=3.1.1,<4.0.0',
 'mkdocs>=1.4.2,<2.0.0',
 'pandas>=1.5.2,<2.0.0']

setup_kwargs = {
    'name': 'gramophone-spotify-pipeline',
    'version': '0.1.0',
    'description': "An exploration of spotify's luigi with spotify's data",
    'long_description': '# Gramophone\nGramophone is an exploration of spotify\'s luigi using spotify\'s api data. This is also a DevOps exercise.\n\n\n[![Build status](https://github.com/TezRomacH/python-package-template/workflows/build/badge.svg?branch=master&event=push)](https://github.com/TezRomacH/python-package-template/actions?query=workflow%3Abuild)\n[![Dependencies Status](https://img.shields.io/badge/dependencies-up%20to%20date-brightgreen.svg)](https://github.com/TezRomacH/python-package-template/pulls?utf8=%E2%9C%93&q=is%3Apr%20author%3Aapp%2Fdependabot)\n\n[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)\n[![Pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white)](https://github.com/dbbvitor/gramophone-spotify-pipeline/blob/main/.pre-commit-config.yaml)\n[![License](https://img.shields.io/github/license/dbbvitor/gramophone-spotify-pipeline)](https://github.com/dbbvitor/gramophone-spotify-pipeline/blob/main/LICENSE)\n![Coverage Report](assets/images/coverage.svg)\n\n\n## Development set up\n\nFollow the instructions bellow to set up your development environment:\n\n0. _(Optional) Install poetry as in the [official docs](https://python-poetry.org/docs/)._\n1. Clone the repository: \n```bash\ngit clone git@github.com:dbbvitor/gramophone-spotify-pipeline.git\n```\n2. Install this project dependencies: \n```bash\npoetry install\n```\n3. Set up the pre-commit hooks\n```bash\npre-commit install \n```\n4. Code away!\n\n\n## Usage\n\nTBD\n\n\n## To-Do\n\n- [ ] Define testing workflow\n- [ ] Define documentation workflow\n- [ ] Setup repository [badges](https://shields.io/category/license)\n\n\n## Contributing\n\nContributions are very welcome. Tests can be run with tox, please ensure the coverage at least stays the same before you submit a pull request.\n\nDistributed under the terms of the `Apache 2.0` license, "Gramophone" is free and open source software.\n\n\nIf you encounter any problems, please file an issue along with a detailed description.',
    'author': 'Me',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
